/*
 * @Author: dongjun 1344851765@qq.com
 * @Date: 2024-08-31 18:46:55
 * @LastEditors: dongjun 1344851765@qq.com
 * @LastEditTime: 2024-08-31 18:50:25
 * @FilePath: \800\static\components\counter-script.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import { CountUp } from '../countUp.min.js';

var options = {
    duration: 4,
    useEasing: true,
    smartEasingThreshold: 500,
    useGrouping: true,
    separator: ',',
    decimal: '.',
    enableScrollSpy: true,
    scrollSpyDelay: 5,
    scrollSpyOnce: true,
};

var counterParent = 
document.getElementById('counter-parent');
var children = counterParent.children;

function countStart(){
    console.log('started');
    $('#counter-parent').addClass('active');
    for (var i = 0; i < children.length; i++){
        var item = document.getElementById(children[i].id).querySelector('.counter');

        var countValue = item.getAttribute('data-value');

        var countUP = new CountUp(item, countValue, options);
    }
}

$( document ).ready(function() {
    console.log('ready');
    countStart();

})


